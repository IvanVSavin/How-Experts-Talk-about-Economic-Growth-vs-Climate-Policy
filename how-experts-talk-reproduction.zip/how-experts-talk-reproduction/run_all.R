# Reproduces every figure, table and number of the paper
# "How Experts Talk about Economic Growth vs Climate Policy: A Linguistic Analysis".
#
# Usage (from this folder):  Rscript run_all.R
# Needs: R >= 4.3, the packages in install_packages.R and pandoc (bundled with RStudio).
#        The (anonymised) data are in data/; data/README.md describes them.
# Output: output/reproduce_results.docx (full report), output/paper_figures/ (every figure of the
#         paper as PNG, 300 dpi, and paper_numbers.csv with every number of the text).

inputs <- c("CompleteReplies.csv", "survey_data_cleanTRv5.RData", "survey_data_lemmatizedv5.csv",
            "calibration_openquestion_v8.RData", "open_v8_10.RData", "outv7.RData", "lca.RData",
            "ai_codes_v3.csv", "ai_codes_v2.csv", "ai_illustrative_quotes.csv",
            "check_AI_coding_completed.xlsx", "check_sample_v2.csv", "answer_lengths.csv")
pkg <- normalizePath(".")
if (!file.exists(file.path(pkg, "analysis", "reproduce_results.Rmd"))) stop("Run this script from the package folder.")
miss <- inputs[!file.exists(file.path(pkg, "data", inputs))]
if (length(miss)) stop("Missing input files in data/: ", paste(miss, collapse = ", "), ". See data/README.md.")

# are these the published files? (MD5 checksums in data/README.md)
md <- grep("^\\| `", readLines(file.path(pkg, "data", "README.md"), encoding = "UTF-8"), value = TRUE)
ref <- setNames(sub(".*`([0-9a-f]{32})` \\|$", "\\1", md), sub("^\\| `([^`]+)`.*", "\\1", md))
now <- tools::md5sum(file.path(pkg, "data", names(ref)))
diff <- names(ref)[unname(now) != ref]
if (length(diff)) warning("These input files differ from the published data: ", paste(diff, collapse = ", "))

# working folder: the Rmd, the prompts and the inputs (the Rmd reads and writes relative to it)
work <- file.path(pkg, "work")
dir.create(file.path(work, "prompts"), recursive = TRUE, showWarnings = FALSE)
file.copy(file.path(pkg, "data", inputs), work, overwrite = TRUE)
file.copy(list.files(file.path(pkg, "prompts"), full.names = TRUE), file.path(work, "prompts"), overwrite = TRUE)
file.copy(file.path(pkg, "analysis", "reproduce_results.Rmd"), work, overwrite = TRUE)
setwd(work)

# envir = globalenv(): stm::estimateEffect() looks up objects in the global environment.
# On Linux/macOS, run with a UTF-8 locale (e.g. LANG=C.UTF-8 Rscript run_all.R).
rmarkdown::render("reproduce_results.Rmd", output_format = "word_document",
                  output_file = "reproduce_results.docx", envir = globalenv(), clean = FALSE)

# the Rmd starts with rm(list = ls()): paths are set again here
work <- getwd(); pkg <- dirname(work); out <- file.path(pkg, "output")
dir.create(file.path(out, "paper_figures"), recursive = TRUE, showWarnings = FALSE)
file.copy("reproduce_results.docx", out, overwrite = TRUE)
file.copy(list.files("paper_figures", full.names = TRUE), file.path(out, "paper_figures"), overwrite = TRUE)

# comparison with the results reported in the paper
a <- read.csv(file.path(out, "paper_figures", "paper_numbers.csv"), header = FALSE, colClasses = "character")
b <- read.csv(file.path(pkg, "expected_output", "paper_figures", "paper_numbers.csv"), header = FALSE, colClasses = "character")
m <- merge(a, b, by = "V1", all = TRUE)
nd <- sum(is.na(m$V2.x) | is.na(m$V2.y) | m$V2.x != m$V2.y)
cat(sprintf("\nNumbers compared with expected_output/: %d, differing: %d\n", nrow(m), nd))
cat("Done. Results in", out, "\n")
