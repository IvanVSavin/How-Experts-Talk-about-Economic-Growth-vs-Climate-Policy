# Installs the R packages needed to run run_all.R (versions used for the paper: R_session_info.txt).
needed <- c("rmarkdown", "knitr", "magrittr", "data.table", "plyr", "dplyr", "tidyr", "tibble", "stringr", "scales",
            "ggplot2", "cowplot", "gridExtra", "lattice", "RColorBrewer", "ggpubr", "corrplot", "dendextend",
            "kableExtra", "janitor", "labelled", "readxl", "cluster", "matrixStats", "R.methodsS3", "car", "caret",
            "irr", "poLCA", "stm", "tm", "ngram", "wordcloud", "sentimentr", "igraph", "tidygraph", "ggraph")
optional <- c("ellmer")   # only to re-run the AI-assisted coding through the API (chunk ai-reproduce, not run by default)
missing <- setdiff(needed, rownames(installed.packages()))
if (length(missing)) install.packages(missing)
cat("All required packages are installed.\n")
