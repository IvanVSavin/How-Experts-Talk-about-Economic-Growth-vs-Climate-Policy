# Quote selection v1 (how the illustrative quotes in `ai_illustrative_quotes.csv` were chosen)

Input: `ai_codes_v2.csv`. Each row is one answer with its codes and up to three verified verbatim quotes (`quote_position`, `quote_meta`, `quote_belief`).

Task: for each category shown in the results (the five meta-reflections; support and criticism of green growth, agrowth, postgrowth and degrowth; decoupling Yes/No; desirability Yes/No; conditional answers), select two quotes that:

1. come from answers coded in that category, and are taken from the quote field that belongs to it;
2. express the category clearly on their own, without needing the rest of the answer;
3. do not mainly express a different category;
4. preferably show two different lines of reasoning, for example an empirical and a normative argument, or respondents from opposite sides;
5. are concise (preferably 8 to 25 words) and are copied verbatim, including typos.

All selected quotes are checked in R against the original answer (section 5 of the Rmd). A fully automatic alternative, which picks for each category the shortest verified quote of 8 or more words from answers coded only in that category, is implemented in the Rmd (`auto_quotes`). It can be used to check that the hand selection does not change the picture.
