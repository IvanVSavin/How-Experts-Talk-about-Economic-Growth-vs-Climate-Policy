# Data

These are the data behind the article, anonymised for publication. Compared with the files used for the analysis:

- **Technical and contact information is removed** from the survey export (`CompleteReplies.csv`): contact ID, session ID, IP address, browser (user agent), referring page, and the location derived from the IP address (coordinates, country, city, region and postcode). The columns are kept, but empty.
- **Identifying details are removed from the free text.** One email address in the comments and three passages in which respondents describe their own role, publication or place of residence are replaced by a note in square brackets, for example `[details of the respondent's role removed]`. The same replacement is made in every file that holds these answers, including the quotes of the AI-assisted coding, so the checks of the quotes still pass. `answer_lengths.csv` keeps the original length of these three answers, which enters the regressions as a control.
- **The reviewers of the AI-assisted coding are numbered** (Reviewer 1 to 3) instead of named in `check_AI_coding_completed.xlsx`.

Everything else is unchanged. With these files, the code reproduces every figure, table and number of the article.

| File | Content | Size (bytes) | MD5 |
| --- | --- | --- | --- |
| `CompleteReplies.csv` | Survey responses as exported from the survey platform | 2,090,962 | `5a3ea0a714aa6e3b9b238c5456f6a71c` |
| `survey_data_cleanTRv5.RData` | Cleaned survey data, with the open-ended responses translated into English | 405,195 | `8a839480ba1b03c7103664a56c45e20e` |
| `survey_data_lemmatizedv5.csv` | Lemmatised open-ended responses | 1,907,540 | `8eb861410f4dab7e32e1df96846a61fe` |
| `calibration_openquestion_v8.RData` | Topic-model inputs and diagnostics for 3 to 20 topics | 2,906,318 | `dfb8b3b4f47a9f5071c6a954eddf7ab3` |
| `open_v8_10.RData` | Structural topic model with ten topics | 3,191,526 | `a73b4668013e74d53168323a4c1ab1db` |
| `outv7.RData` | Metadata of the topic model | 532,539 | `ae7e108ffe8d5318480e4af37e9260b4` |
| `lca.RData` | Latent-class models of the growth statements (working analyses) | 377,851 | `0c505997a0f5ea653cd5ee300ce82f08` |
| `ai_codes_v3.csv` | AI-assisted coding of every response (coding used in the paper) | 1,015,331 | `10229211a76e1f88a30db887b24b731d` |
| `ai_codes_v2.csv` | First AI-assisted coding (v2), before the growth positions were redefined | 770,586 | `c48a34c35aabb565ae5851d9c740987b` |
| `ai_illustrative_quotes.csv` | Selected illustrative quotes | 7,526 | `99aa54dbf8b4f37d70dccde7b4572d9f` |
| `check_AI_coding_completed.xlsx` | The authors' review of 300 coded responses | 104,453 | `e56d61b9e6ab4b2af8e53dc361f0ba1b` |
| `check_sample_v2.csv` | The 300 sampled responses of the review | 231,550 | `59c50634e187e15343e8f3ba7e48bfb8` |
| `answer_lengths.csv` | Original length (in words) of the three answers from which identifying details were removed | 49 | `3542a93cdb72567aa9e821a2141871b3` |
